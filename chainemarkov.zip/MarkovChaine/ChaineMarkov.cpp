#include <iostream>
#include "ChaineMarkov.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;
ChaineMarkov::ChaineMarkov(double p)
{
    matrice = new double*[5];
    for(int i=0;i<5;i++)
    matrice[i] = new double[5];

    //ligne 1
    matrice[0][0] = 0;
    matrice[0][1] = 1-p;
    matrice[0][2] = 0;
    matrice[0][3] = 0;
    matrice[0][4] = p;
    //ligne 2
    matrice[1][0] = 0;
    matrice[1][1] = 0;
    matrice[1][2] = 1-p;
    matrice[1][3] = 0;
    matrice[1][4] = p;
    //ligne 3
    matrice[2][0] = 0;
    matrice[2][1] = 0;
    matrice[2][2] = 0;
    matrice[2][3] = 1-p;
    matrice[2][4] = p;
    //ligne 4
    matrice[3][0] = 1;
    matrice[3][1] = 0;
    matrice[3][2] = 0;
    matrice[3][3] = 0;
    matrice[3][4] = 0;
    //ligne 5
    matrice[4][0] = 1;
    matrice[4][1] = 0;
    matrice[4][2] = 0;
    matrice[4][3] = 0;
    matrice[4][4] = 0;
    //Affichage de la matrice
    for(int i = 0; i < 5; i++)
    {
        for(int j=0;j<5;j++)
            cout << matrice[i][j] << "\t";
        cout << endl;
    }
}


ChaineMarkov::~ChaineMarkov()
{
    if(matrice != NULL) delete matrice;
}

void ChaineMarkov::Executer()
{
    int etat = 0;
    int temp =0;
    double *pi;
    pi = matrice[etat];
    //Affichage du vecteur Pi
    cout << "\nEtat = "<< etat << "       Temp = " << temp;
    cout << "\nVecteur Pi : \n";
    for(int i=0;i<5;i++)
    cout << pi[i] << "\t";
    cout << endl;
    double r = Random();
    double s = 0;
    for(int i=0;i<5;i++)
    {
        s+= pi[i];
        if(s > r)
        {
            etat = i;
            break;
        }
    }
    temp++;
}

double ChaineMarkov::Random()
{
    return (double) rand()/RAND_MAX;
}

#include <iostream>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "ChaineMarkov.h"
#include <cstdlib>

using namespace std;

int main(int argc , char** argv)
{
    ChaineMarkov *chaine = new ChaineMarkov(0.3);
    chaine -> Executer();

    return 0;
}

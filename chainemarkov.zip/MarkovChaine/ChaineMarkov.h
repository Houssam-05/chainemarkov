#include <math.h>
#include <stdio.h>
#include <stdlib.h>

class ChaineMarkov
{
private:
    double **matrice;
    double Random();
public:
    ChaineMarkov(double p);
    ~ChaineMarkov();
    void Executer();
};
